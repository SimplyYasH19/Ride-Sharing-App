import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const getCurrentProfile = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return null;

    const profile = await ctx.db
      .query("profiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    return profile;
  },
});

export const createProfile = mutation({
  args: {
    name: v.string(),
    phone: v.string(),
    role: v.union(v.literal("rider"), v.literal("driver")),
    vehicleInfo: v.optional(v.object({
      make: v.string(),
      model: v.string(),
      year: v.number(),
      licensePlate: v.string(),
      color: v.string(),
    })),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    // Check if profile already exists
    const existingProfile = await ctx.db
      .query("profiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (existingProfile) {
      throw new Error("Profile already exists");
    }

    const profileData = {
      userId,
      name: args.name,
      phone: args.phone,
      role: args.role,
      rating: 5.0,
      ...(args.role === "driver" && {
        vehicleInfo: args.vehicleInfo,
        isOnline: false,
      }),
    };

    return await ctx.db.insert("profiles", profileData);
  },
});

export const updateDriverStatus = mutation({
  args: {
    isOnline: v.boolean(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const profile = await ctx.db
      .query("profiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!profile || profile.role !== "driver") {
      throw new Error("Driver profile not found");
    }

    await ctx.db.patch(profile._id, { isOnline: args.isOnline });

    // Update driver location status
    const driverLocation = await ctx.db
      .query("driverLocations")
      .withIndex("by_driver", (q) => q.eq("driverId", profile._id))
      .unique();

    if (driverLocation) {
      await ctx.db.patch(driverLocation._id, { isOnline: args.isOnline });
    }

    return profile._id;
  },
});

export const getOnlineDrivers = query({
  args: {},
  handler: async (ctx) => {
    const drivers = await ctx.db
      .query("profiles")
      .withIndex("by_role", (q) => q.eq("role", "driver"))
      .filter((q) => q.eq(q.field("isOnline"), true))
      .collect();

    const driversWithLocations = await Promise.all(
      drivers.map(async (driver) => {
        const location = await ctx.db
          .query("driverLocations")
          .withIndex("by_driver", (q) => q.eq("driverId", driver._id))
          .unique();

        return {
          ...driver,
          location,
        };
      })
    );

    return driversWithLocations.filter(driver => driver.location);
  },
});

export const getAllDriversDebug = query({
  args: {},
  handler: async (ctx) => {
    const allDrivers = await ctx.db
      .query("profiles")
      .withIndex("by_role", (q) => q.eq("role", "driver"))
      .collect();

    const driversWithDetails = await Promise.all(
      allDrivers.map(async (driver) => {
        const location = await ctx.db
          .query("driverLocations")
          .withIndex("by_driver", (q) => q.eq("driverId", driver._id))
          .unique();

        return {
          name: driver.name,
          isOnline: driver.isOnline || false,
          hasLocation: !!location,
          location: location ? {
            latitude: location.latitude,
            longitude: location.longitude,
            isOnline: location.isOnline
          } : null
        };
      })
    );

    return driversWithDetails;
  },
});
