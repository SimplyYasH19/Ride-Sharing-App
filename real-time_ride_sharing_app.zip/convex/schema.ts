import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  // User profiles with role-based access
  profiles: defineTable({
    userId: v.id("users"),
    name: v.string(),
    phone: v.string(),
    role: v.union(v.literal("rider"), v.literal("driver")),
    // Driver-specific fields
    vehicleInfo: v.optional(v.object({
      make: v.string(),
      model: v.string(),
      year: v.number(),
      licensePlate: v.string(),
      color: v.string(),
    })),
    isOnline: v.optional(v.boolean()), // For drivers
    rating: v.optional(v.number()),
  }).index("by_user", ["userId"]).index("by_role", ["role"]),

  // Real-time driver locations
  driverLocations: defineTable({
    driverId: v.id("profiles"),
    latitude: v.number(),
    longitude: v.number(),
    heading: v.optional(v.number()), // Direction in degrees
    isOnline: v.boolean(),
  }).index("by_driver", ["driverId"]).index("by_online", ["isOnline"]),

  // Ride requests and tracking
  rides: defineTable({
    riderId: v.id("profiles"),
    driverId: v.optional(v.id("profiles")),
    status: v.union(
      v.literal("requested"),
      v.literal("accepted"),
      v.literal("driver_on_way"),
      v.literal("driver_arrived"),
      v.literal("in_progress"),
      v.literal("completed"),
      v.literal("cancelled")
    ),
    pickupLocation: v.object({
      latitude: v.number(),
      longitude: v.number(),
      address: v.string(),
    }),
    destination: v.object({
      latitude: v.number(),
      longitude: v.number(),
      address: v.string(),
    }),
    estimatedFare: v.optional(v.number()),
    actualFare: v.optional(v.number()),
    estimatedDuration: v.optional(v.number()), // in minutes
    requestedAt: v.number(),
    acceptedAt: v.optional(v.number()),
    completedAt: v.optional(v.number()),
  }).index("by_rider", ["riderId"])
    .index("by_driver", ["driverId"])
    .index("by_status", ["status"]),

  // Real-time ride tracking
  rideTracking: defineTable({
    rideId: v.id("rides"),
    driverLatitude: v.number(),
    driverLongitude: v.number(),
    estimatedArrival: v.optional(v.number()), // timestamp
  }).index("by_ride", ["rideId"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
