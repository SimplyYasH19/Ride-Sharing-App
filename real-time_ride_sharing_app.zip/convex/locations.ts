import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const updateDriverLocation = mutation({
  args: {
    latitude: v.number(),
    longitude: v.number(),
    heading: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const profile = await ctx.db
      .query("profiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!profile || profile.role !== "driver") {
      throw new Error("Driver profile not found");
    }

    const existingLocation = await ctx.db
      .query("driverLocations")
      .withIndex("by_driver", (q) => q.eq("driverId", profile._id))
      .unique();

    const locationData = {
      driverId: profile._id,
      latitude: args.latitude,
      longitude: args.longitude,
      heading: args.heading,
      isOnline: profile.isOnline || false,
    };

    if (existingLocation) {
      await ctx.db.patch(existingLocation._id, locationData);
      return existingLocation._id;
    } else {
      return await ctx.db.insert("driverLocations", locationData);
    }
  },
});

export const getNearbyDrivers = query({
  args: {
    latitude: v.number(),
    longitude: v.number(),
    radiusKm: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const radius = args.radiusKm || 10; // Default 10km radius
    
    const onlineDrivers = await ctx.db
      .query("driverLocations")
      .withIndex("by_online", (q) => q.eq("isOnline", true))
      .collect();

    // Simple distance calculation (not perfectly accurate but good enough for demo)
    const driversWithDistance = onlineDrivers
      .map(driver => {
        const latDiff = driver.latitude - args.latitude;
        const lonDiff = driver.longitude - args.longitude;
        const distance = Math.sqrt(latDiff * latDiff + lonDiff * lonDiff) * 111; // Rough km conversion
        
        return {
          ...driver,
          distance,
        };
      })
      .filter(driver => driver.distance <= radius)
      .sort((a, b) => a.distance - b.distance);

    // Get driver profiles
    return await Promise.all(
      driversWithDistance.map(async (driverLocation) => {
        const profile = await ctx.db.get(driverLocation.driverId);
        return {
          ...driverLocation,
          profile,
        };
      })
    );
  },
});

export const updateRideTracking = mutation({
  args: {
    rideId: v.id("rides"),
    driverLatitude: v.number(),
    driverLongitude: v.number(),
    estimatedArrival: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const profile = await ctx.db
      .query("profiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!profile || profile.role !== "driver") {
      throw new Error("Driver profile not found");
    }

    const ride = await ctx.db.get(args.rideId);
    if (!ride || ride.driverId !== profile._id) {
      throw new Error("Ride not found or not assigned to you");
    }

    const existingTracking = await ctx.db
      .query("rideTracking")
      .withIndex("by_ride", (q) => q.eq("rideId", args.rideId))
      .unique();

    const trackingData = {
      rideId: args.rideId,
      driverLatitude: args.driverLatitude,
      driverLongitude: args.driverLongitude,
      estimatedArrival: args.estimatedArrival,
    };

    if (existingTracking) {
      await ctx.db.patch(existingTracking._id, trackingData);
      return existingTracking._id;
    } else {
      return await ctx.db.insert("rideTracking", trackingData);
    }
  },
});

export const getRideTracking = query({
  args: {
    rideId: v.id("rides"),
  },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("rideTracking")
      .withIndex("by_ride", (q) => q.eq("rideId", args.rideId))
      .unique();
  },
});
