import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const requestRide = mutation({
  args: {
    pickupLocation: v.object({
      latitude: v.number(),
      longitude: v.number(),
      address: v.string(),
    }),
    destination: v.object({
      latitude: v.number(),
      longitude: v.number(),
      address: v.string(),
    }),
    estimatedFare: v.number(),
    estimatedDuration: v.number(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const profile = await ctx.db
      .query("profiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!profile || profile.role !== "rider") {
      throw new Error("Rider profile not found");
    }

    // Check if rider has an active ride
    const activeRide = await ctx.db
      .query("rides")
      .withIndex("by_rider", (q) => q.eq("riderId", profile._id))
      .filter((q) => 
        q.or(
          q.eq(q.field("status"), "requested"),
          q.eq(q.field("status"), "accepted"),
          q.eq(q.field("status"), "driver_on_way"),
          q.eq(q.field("status"), "driver_arrived"),
          q.eq(q.field("status"), "in_progress")
        )
      )
      .unique();

    if (activeRide) {
      throw new Error("You already have an active ride");
    }

    return await ctx.db.insert("rides", {
      riderId: profile._id,
      status: "requested",
      pickupLocation: args.pickupLocation,
      destination: args.destination,
      estimatedFare: args.estimatedFare,
      estimatedDuration: args.estimatedDuration,
      requestedAt: Date.now(),
    });
  },
});

export const getAvailableRides = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    const profile = await ctx.db
      .query("profiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!profile || profile.role !== "driver") {
      return [];
    }

    const rides = await ctx.db
      .query("rides")
      .withIndex("by_status", (q) => q.eq("status", "requested"))
      .collect();

    return await Promise.all(
      rides.map(async (ride) => {
        const rider = await ctx.db.get(ride.riderId);
        return {
          ...ride,
          rider,
        };
      })
    );
  },
});

export const acceptRide = mutation({
  args: {
    rideId: v.id("rides"),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const profile = await ctx.db
      .query("profiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!profile || profile.role !== "driver") {
      throw new Error("Driver profile not found");
    }

    const ride = await ctx.db.get(args.rideId);
    if (!ride || ride.status !== "requested") {
      throw new Error("Ride not available");
    }

    // Check if driver has an active ride
    const activeRide = await ctx.db
      .query("rides")
      .withIndex("by_driver", (q) => q.eq("driverId", profile._id))
      .filter((q) => 
        q.or(
          q.eq(q.field("status"), "accepted"),
          q.eq(q.field("status"), "driver_on_way"),
          q.eq(q.field("status"), "driver_arrived"),
          q.eq(q.field("status"), "in_progress")
        )
      )
      .unique();

    if (activeRide) {
      throw new Error("You already have an active ride");
    }

    await ctx.db.patch(args.rideId, {
      driverId: profile._id,
      status: "accepted",
      acceptedAt: Date.now(),
    });

    return args.rideId;
  },
});

export const updateRideStatus = mutation({
  args: {
    rideId: v.id("rides"),
    status: v.union(
      v.literal("driver_on_way"),
      v.literal("driver_arrived"),
      v.literal("in_progress"),
      v.literal("completed"),
      v.literal("cancelled")
    ),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const profile = await ctx.db
      .query("profiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!profile || profile.role !== "driver") {
      throw new Error("Driver profile not found");
    }

    const ride = await ctx.db.get(args.rideId);
    if (!ride || ride.driverId !== profile._id) {
      throw new Error("Ride not found or not assigned to you");
    }

    const updateData: any = { status: args.status };
    if (args.status === "completed") {
      updateData.completedAt = Date.now();
    }

    await ctx.db.patch(args.rideId, updateData);
    return args.rideId;
  },
});

export const getCurrentRide = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return null;

    const profile = await ctx.db
      .query("profiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!profile) return null;

    let ride;
    if (profile.role === "rider") {
      ride = await ctx.db
        .query("rides")
        .withIndex("by_rider", (q) => q.eq("riderId", profile._id))
        .filter((q) => 
          q.or(
            q.eq(q.field("status"), "requested"),
            q.eq(q.field("status"), "accepted"),
            q.eq(q.field("status"), "driver_on_way"),
            q.eq(q.field("status"), "driver_arrived"),
            q.eq(q.field("status"), "in_progress")
          )
        )
        .unique();
    } else {
      ride = await ctx.db
        .query("rides")
        .withIndex("by_driver", (q) => q.eq("driverId", profile._id))
        .filter((q) => 
          q.or(
            q.eq(q.field("status"), "accepted"),
            q.eq(q.field("status"), "driver_on_way"),
            q.eq(q.field("status"), "driver_arrived"),
            q.eq(q.field("status"), "in_progress")
          )
        )
        .unique();
    }

    if (!ride) return null;

    // Get additional data based on role
    let additionalData = {};
    if (profile.role === "rider" && ride.driverId) {
      const driver = await ctx.db.get(ride.driverId);
      const driverLocation = await ctx.db
        .query("driverLocations")
        .withIndex("by_driver", (q) => q.eq("driverId", ride.driverId!))
        .unique();
      additionalData = { driver, driverLocation };
    } else if (profile.role === "driver") {
      const rider = await ctx.db.get(ride.riderId);
      additionalData = { rider };
    }

    return {
      ...ride,
      ...additionalData,
    };
  },
});

export const cancelRide = mutation({
  args: {
    rideId: v.id("rides"),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const profile = await ctx.db
      .query("profiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!profile) throw new Error("Profile not found");

    const ride = await ctx.db.get(args.rideId);
    if (!ride) throw new Error("Ride not found");

    // Check if user can cancel this ride
    const canCancel = (profile.role === "rider" && ride.riderId === profile._id) ||
                     (profile.role === "driver" && ride.driverId === profile._id);

    if (!canCancel) {
      throw new Error("You cannot cancel this ride");
    }

    await ctx.db.patch(args.rideId, { status: "cancelled" });
    return args.rideId;
  },
});
