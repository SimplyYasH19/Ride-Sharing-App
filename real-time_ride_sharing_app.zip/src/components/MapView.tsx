import { useEffect, useRef } from "react";
import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";

export function MapView() {
  const mapRef = useRef<HTMLDivElement>(null);
  const profile = useQuery(api.profiles.getCurrentProfile);
  const onlineDrivers = useQuery(api.profiles.getOnlineDrivers);
  const allDriversDebug = useQuery(api.profiles.getAllDriversDebug);
  const currentRide = useQuery(api.rides.getCurrentRide);

  useEffect(() => {
    // This is a placeholder for map integration
    // In a real app, you would integrate with Google Maps, Mapbox, or similar
    if (mapRef.current) {
      // Initialize map here
    }
  }, []);

  return (
    <div ref={mapRef} className="w-full h-full bg-gray-200 relative">
      {/* Placeholder Map */}
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="text-center">
          <div className="text-6xl mb-4">🗺️</div>
          <p className="text-gray-600 mb-2">Map Integration Placeholder</p>
          <p className="text-sm text-gray-500">
            In a real app, integrate with Google Maps or Mapbox API
          </p>
          
          {/* Show some basic info */}
          <div className="mt-6 bg-white rounded-lg p-4 shadow-sm max-w-sm">
            {profile?.role === "rider" && (
              <div>
                <p className="font-medium">Rider View</p>
                <p className="text-sm text-gray-600">
                  {onlineDrivers?.length || 0} drivers online nearby
                </p>
                {allDriversDebug && (
                  <p className="text-xs text-gray-500 mt-1">
                    Debug: {allDriversDebug.length} total, {allDriversDebug.filter(d => d.isOnline).length} online, {allDriversDebug.filter(d => d.hasLocation).length} with location
                  </p>
                )}
              </div>
            )}
            
            {profile?.role === "driver" && (
              <div>
                <p className="font-medium">Driver View</p>
                <p className="text-sm text-gray-600">
                  Status: {profile.isOnline ? "Online" : "Offline"}
                </p>
              </div>
            )}
            
            {currentRide && (
              <div className="mt-2 pt-2 border-t">
                <p className="text-sm font-medium">Active Ride</p>
                <p className="text-xs text-gray-600">Status: {currentRide.status}</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
