import { useState, useEffect } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";
import { MapView } from "./MapView";
import { RideRequest } from "./RideRequest";
import { ActiveRide } from "./ActiveRide";

export function RiderDashboard() {
  const currentRide = useQuery(api.rides.getCurrentRide);
  const [showRequestForm, setShowRequestForm] = useState(false);

  if (currentRide === undefined) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="h-[calc(100vh-4rem)] flex flex-col">
      {/* Map Container */}
      <div className="flex-1 relative">
        <MapView />
        
        {/* Floating Action Button */}
        {!currentRide && !showRequestForm && (
          <button
            onClick={() => setShowRequestForm(true)}
            className="absolute bottom-6 left-1/2 transform -translate-x-1/2 bg-blue-600 text-white px-8 py-4 rounded-full shadow-lg hover:bg-blue-700 transition-colors font-semibold text-lg z-10"
          >
            Request a Ride
          </button>
        )}
      </div>

      {/* Bottom Panel */}
      <div className="bg-white border-t shadow-lg">
        {showRequestForm && !currentRide && (
          <RideRequest onClose={() => setShowRequestForm(false)} />
        )}
        
        {currentRide && (
          <ActiveRide ride={currentRide} />
        )}
        
        {!currentRide && !showRequestForm && (
          <div className="p-6 text-center">
            <h2 className="text-xl font-semibold mb-2">Ready for your next ride?</h2>
            <p className="text-gray-600">Tap the button above to get started</p>
          </div>
        )}
      </div>
    </div>
  );
}
