import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

export function AvailableRides() {
  const availableRides = useQuery(api.rides.getAvailableRides);
  const acceptRide = useMutation(api.rides.acceptRide);

  const handleAcceptRide = async (rideId: string) => {
    try {
      await acceptRide({ rideId: rideId as any });
      toast.success("Ride accepted!");
    } catch (error) {
      toast.error("Failed to accept ride");
      console.error(error);
    }
  };

  if (availableRides === undefined) {
    return (
      <div className="p-6 text-center">
        <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary mx-auto"></div>
      </div>
    );
  }

  if (availableRides.length === 0) {
    return (
      <div className="p-6 text-center">
        <h2 className="text-xl font-semibold mb-2">No rides available</h2>
        <p className="text-gray-600">New ride requests will appear here</p>
      </div>
    );
  }

  return (
    <div className="p-4">
      <h2 className="text-lg font-semibold mb-4">Available Rides ({availableRides.length})</h2>
      <div className="space-y-3">
        {availableRides.map((ride) => (
          <div key={ride._id} className="bg-gray-50 rounded-lg p-4 border">
            <div className="flex justify-between items-start mb-3">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-sm font-medium text-gray-600">👤</span>
                  <span className="font-medium">{ride.rider?.name}</span>
                </div>
                
                <div className="space-y-1 text-sm">
                  <div className="flex items-start gap-2">
                    <span className="text-green-600 mt-0.5">📍</span>
                    <span className="text-gray-700">{ride.pickupLocation.address}</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="text-red-600 mt-0.5">🎯</span>
                    <span className="text-gray-700">{ride.destination.address}</span>
                  </div>
                </div>
              </div>
              
              <div className="text-right">
                <div className="text-lg font-semibold text-green-600">
                  ${ride.estimatedFare}
                </div>
                <div className="text-sm text-gray-500">
                  ~{ride.estimatedDuration} min
                </div>
              </div>
            </div>
            
            <div className="flex justify-between items-center">
              <span className="text-xs text-gray-500">
                Requested {new Date(ride.requestedAt).toLocaleTimeString()}
              </span>
              <button
                onClick={() => handleAcceptRide(ride._id)}
                className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors font-medium"
              >
                Accept Ride
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
