import { useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

interface ActiveRideProps {
  ride: any;
}

export function ActiveRide({ ride }: ActiveRideProps) {
  const updateRideStatus = useMutation(api.rides.updateRideStatus);
  const cancelRide = useMutation(api.rides.cancelRide);

  const handleStatusUpdate = async (status: string) => {
    try {
      await updateRideStatus({ rideId: ride._id, status: status as any });
      toast.success(`Ride status updated to: ${status.replace('_', ' ')}`);
    } catch (error) {
      toast.error("Failed to update ride status");
      console.error(error);
    }
  };

  const handleCancelRide = async () => {
    if (!confirm("Are you sure you want to cancel this ride?")) return;
    
    try {
      await cancelRide({ rideId: ride._id });
      toast.success("Ride cancelled");
    } catch (error) {
      toast.error("Failed to cancel ride");
      console.error(error);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "requested": return "bg-yellow-100 text-yellow-800";
      case "accepted": return "bg-blue-100 text-blue-800";
      case "driver_on_way": return "bg-purple-100 text-purple-800";
      case "driver_arrived": return "bg-green-100 text-green-800";
      case "in_progress": return "bg-indigo-100 text-indigo-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case "requested": return "Looking for driver...";
      case "accepted": return "Driver assigned";
      case "driver_on_way": return "Driver on the way";
      case "driver_arrived": return "Driver has arrived";
      case "in_progress": return "Trip in progress";
      default: return status.replace('_', ' ');
    }
  };

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold">Current Ride</h2>
        <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(ride.status)}`}>
          {getStatusText(ride.status)}
        </span>
      </div>

      <div className="space-y-4">
        {/* Ride Details */}
        <div className="bg-gray-50 rounded-lg p-4">
          <div className="space-y-2 text-sm">
            <div className="flex items-start gap-2">
              <span className="text-green-600 mt-0.5">📍</span>
              <div>
                <div className="font-medium">Pickup</div>
                <div className="text-gray-600">{ride.pickupLocation.address}</div>
              </div>
            </div>
            <div className="flex items-start gap-2">
              <span className="text-red-600 mt-0.5">🎯</span>
              <div>
                <div className="font-medium">Destination</div>
                <div className="text-gray-600">{ride.destination.address}</div>
              </div>
            </div>
          </div>
        </div>

        {/* Driver/Rider Info */}
        {ride.driver && (
          <div className="bg-blue-50 rounded-lg p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-200 rounded-full flex items-center justify-center">
                🚗
              </div>
              <div>
                <div className="font-medium">{ride.driver.name}</div>
                <div className="text-sm text-gray-600">
                  {ride.driver.vehicleInfo?.color} {ride.driver.vehicleInfo?.make} {ride.driver.vehicleInfo?.model}
                </div>
                <div className="text-sm text-gray-600">
                  {ride.driver.vehicleInfo?.licensePlate}
                </div>
              </div>
            </div>
          </div>
        )}

        {ride.rider && (
          <div className="bg-green-50 rounded-lg p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-green-200 rounded-full flex items-center justify-center">
                👤
              </div>
              <div>
                <div className="font-medium">{ride.rider.name}</div>
                <div className="text-sm text-gray-600">{ride.rider.phone}</div>
              </div>
            </div>
          </div>
        )}

        {/* Fare Info */}
        <div className="flex justify-between items-center py-2 border-t">
          <span className="font-medium">Estimated Fare</span>
          <span className="text-lg font-semibold text-green-600">
            ${ride.estimatedFare}
          </span>
        </div>

        {/* Action Buttons */}
        <div className="space-y-2">
          {/* Driver Actions */}
          {ride.driver && ride.status === "accepted" && (
            <button
              onClick={() => handleStatusUpdate("driver_on_way")}
              className="w-full px-4 py-3 bg-blue-600 text-white rounded-md hover:bg-blue-700 font-medium"
            >
              Start Trip - On My Way
            </button>
          )}
          
          {ride.driver && ride.status === "driver_on_way" && (
            <button
              onClick={() => handleStatusUpdate("driver_arrived")}
              className="w-full px-4 py-3 bg-green-600 text-white rounded-md hover:bg-green-700 font-medium"
            >
              I've Arrived
            </button>
          )}
          
          {ride.driver && ride.status === "driver_arrived" && (
            <button
              onClick={() => handleStatusUpdate("in_progress")}
              className="w-full px-4 py-3 bg-purple-600 text-white rounded-md hover:bg-purple-700 font-medium"
            >
              Start Trip
            </button>
          )}
          
          {ride.driver && ride.status === "in_progress" && (
            <button
              onClick={() => handleStatusUpdate("completed")}
              className="w-full px-4 py-3 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 font-medium"
            >
              Complete Trip
            </button>
          )}

          {/* Cancel Button */}
          {ride.status !== "completed" && (
            <button
              onClick={handleCancelRide}
              className="w-full px-4 py-2 border border-red-300 text-red-700 rounded-md hover:bg-red-50 font-medium"
            >
              Cancel Ride
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
