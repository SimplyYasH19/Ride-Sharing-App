import { useState, useEffect } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";
import { MapView } from "./MapView";
import { AvailableRides } from "./AvailableRides";
import { ActiveRide } from "./ActiveRide";

export function DriverDashboard() {
  const profile = useQuery(api.profiles.getCurrentProfile);
  const currentRide = useQuery(api.rides.getCurrentRide);
  const updateDriverStatus = useMutation(api.profiles.updateDriverStatus);
  const updateLocation = useMutation(api.locations.updateDriverLocation);
  
  const [isOnline, setIsOnline] = useState(false);

  useEffect(() => {
    if (profile) {
      setIsOnline(profile.isOnline || false);
    }
  }, [profile]);

  // Update location every 10 seconds when online
  useEffect(() => {
    if (!isOnline) return;

    const updateCurrentLocation = () => {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            updateLocation({
              latitude: position.coords.latitude,
              longitude: position.coords.longitude,
              heading: position.coords.heading || undefined,
            }).catch(console.error);
          },
          (error) => {
            console.error("Location error:", error);
            if (error.code === error.PERMISSION_DENIED) {
              toast.error("Location permission denied. Please enable location access to go online.");
              setIsOnline(false);
              updateDriverStatus({ isOnline: false }).catch(console.error);
            }
          },
          { enableHighAccuracy: true }
        );
      }
    };

    updateCurrentLocation();
    const interval = setInterval(updateCurrentLocation, 10000);
    return () => clearInterval(interval);
  }, [isOnline, updateLocation]);

  const toggleOnlineStatus = async () => {
    try {
      const newStatus = !isOnline;
      await updateDriverStatus({ isOnline: newStatus });
      setIsOnline(newStatus);
      toast.success(newStatus ? "You're now online!" : "You're now offline");
    } catch (error) {
      toast.error("Failed to update status");
      console.error(error);
    }
  };

  if (profile === undefined || currentRide === undefined) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="h-[calc(100vh-4rem)] flex flex-col">
      {/* Status Bar */}
      <div className="bg-white border-b px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className={`w-3 h-3 rounded-full ${isOnline ? 'bg-green-500' : 'bg-gray-400'}`}></div>
          <span className="font-medium">
            {isOnline ? 'Online' : 'Offline'}
          </span>
        </div>
        <button
          onClick={toggleOnlineStatus}
          className={`px-4 py-2 rounded-md font-medium transition-colors ${
            isOnline 
              ? 'bg-red-100 text-red-700 hover:bg-red-200' 
              : 'bg-green-100 text-green-700 hover:bg-green-200'
          }`}
        >
          {isOnline ? 'Go Offline' : 'Go Online'}
        </button>
      </div>

      {/* Map Container */}
      <div className="flex-1 relative">
        <MapView />
      </div>

      {/* Bottom Panel */}
      <div className="bg-white border-t shadow-lg max-h-80 overflow-y-auto">
        {currentRide ? (
          <ActiveRide ride={currentRide} />
        ) : isOnline ? (
          <AvailableRides />
        ) : (
          <div className="p-6 text-center">
            <h2 className="text-xl font-semibold mb-2">You're offline</h2>
            <p className="text-gray-600">Go online to start receiving ride requests</p>
          </div>
        )}
      </div>
    </div>
  );
}
